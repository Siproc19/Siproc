# SIPROC FEL INFILE Guatemala — `modulo_infile`

Módulo de **Facturación Electrónica (FEL) para Guatemala** con el certificador **INFILE (FEEL)**, compatible con Odoo 19.

---

## ✨ Funcionalidades

- Certificación de **facturas** (FACT, FPEQ, FCAM)
- Certificación de **notas de crédito** (NCRE) y **notas de débito** (NDEB)
- **Anulación** de documentos certificados ante SAT
- **Consulta de NIT** en tiempo real en el portal SAT
- **Firma electrónica** de documentos XML
- Almacenamiento del XML enviado y la respuesta de INFILE
- Visualización del **PDF certificado** directamente en Odoo
- **Tarea programada (cron)** para reintento automático de certificaciones fallidas

---

## 🛠️ Instalación

1. Copiar la carpeta `modulo_infile` a los addons de Odoo.
2. Actualizar lista de aplicaciones.
3. Instalar **"SIPROC FEL INFILE Guatemala"**.

**Versión:** `19.0.1.0.0`  
**Dependencias:** `account`, `contacts`

---

## ⚙️ Configuración

1. Ir a **Ajustes → Contabilidad → FEL Guatemala**.
2. Ingresar las credenciales proporcionadas por INFILE:

   | Campo | Descripción |
   |-------|-------------|
   | NIT Emisor | NIT de la empresa emisora |
   | Usuario API | Usuario del servicio INFILE |
   | Llave API | Contraseña / token del servicio |
   | Usuario Firma | Usuario del servicio de firma |
   | Llave Firma | Contraseña del servicio de firma |

3. Configurar **Afiliación IVA** (General, Pequeño Contribuyente, etc.) y **Régimen ISR**.

---

## 📋 Uso

1. Crear y publicar una **factura de cliente** en Odoo.
2. Hacer clic en el botón **"Certificar FEL"**.
3. El documento quedará certificado y mostrará el **UUID de SAT** y el **número de autorización**.

---

## 📂 Estructura

```
modulo_infile/
├── data/
│   ├── ir_config_parameter.xml     # Parámetros de configuración
│   └── ir_cron.xml                 # Tarea programada de reintento
├── models/
│   ├── account_move.py             # Extensión de facturas
│   ├── fel_service.py              # Servicio de comunicación con INFILE
│   ├── res_config_settings.py      # Ajustes del módulo
│   └── res_partner.py              # Extensión de contactos (NIT, tipo)
├── report/
│   └── fel_dte_report.xml          # Reporte PDF del DTE certificado
├── views/
│   ├── account_move_view.xml
│   ├── res_config_settings_view.xml
│   └── res_partner_view.xml
└── security/
    └── ir.model.access.csv
```

---

## 📄 Licencia

LGPL-3 — © Ronald de León / SIPROC — [siproc.com](https://siproc.com)
