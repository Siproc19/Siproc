from . import fel_service
from . import account_move
from . import res_config_settings
from . import res_partner
