# SIPROC Sales Bonus — `siproc_sales_bonus`

Módulo de **bonificaciones para el equipo de ventas** de SIPROC en Odoo 19.

---

## Estado

> 🔧 **En desarrollo.** Este módulo actualmente solo define la estructura base (manifest). La lógica de negocio, modelos y vistas están pendientes de implementación.

---

## 🛠️ Instalación

1. Copiar la carpeta `siproc_sales_bonus` a los addons de Odoo.
2. Actualizar lista de aplicaciones.
3. Instalar **"SIPROC Sales Bonus"**.

**Versión:** `19.0.1.0`  
**Dependencias:** `base`, `mail`, `sale_management`

---

## 📄 Licencia

LGPL-3 — © SIPROC
