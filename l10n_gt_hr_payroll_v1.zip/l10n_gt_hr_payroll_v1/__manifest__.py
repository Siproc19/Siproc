# -*- coding: utf-8 -*-
{
    "name": "Guatemala Payroll Localization",
    "version": "19.0.1.0.0",
    "summary": "Payroll localization for Guatemala on Odoo 19 Enterprise",
    "description": """
Guatemala Payroll Localization for Odoo 19 Enterprise
=====================================================
- Employee and contract GT fields
- Legal parameters by company and validity dates
- Vacations, Aguinaldo, Bono 14
- IGSS, IRTRA, INTECAP
- Liquidations / finiquitos
- Work entry integration
- Payroll reports and audit trail
""",
    "author": "OpenAI - Draft Base",
    "website": "https://www.odoo.com",
    "license": "OEEL-1",
    "category": "Human Resources/Payroll",
    "depends": [
        "hr",
        "hr_contract",
        "hr_holidays",
        "hr_attendance",
        "hr_payroll",
        "hr_work_entry_contract",
        "planning",
        "account",
        "mail",
    ],
    "data": [
        "security/security.xml",
        "security/ir.model.access.csv",
        "data/sequence.xml",
        "data/work_entry_types.xml",
        "data/salary_rule_parameters.xml",
        "views/menu.xml",
        "views/res_company_views.xml",
        "views/hr_employee_views.xml",
        "views/hr_contract_views.xml",
        "views/hr_leave_views.xml",
        "views/hr_payslip_views.xml",
        "views/payroll_parameter_views.xml",
        "views/overtime_views.xml",
        "views/liquidation_views.xml",
        "report/payroll_reports.xml",
        "report/report_templates.xml",
    ],
    "demo": [],
    "installable": True,
    "application": False,
}
